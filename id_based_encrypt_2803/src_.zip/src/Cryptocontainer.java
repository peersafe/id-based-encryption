/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author foxneig
 */
public class Cryptocontainer {
    int firstKeySize;
    int secondKeySize;
    int encryptedDataSize;
    int signatureSize;
    int dataSize;

    void writeParam (int dataSize, int firstKeySize, int secondKeySize, int encryptedDataSize, int signatureSize) {
        this.dataSize = dataSize;
        this.firstKeySize = firstKeySize;
        this.secondKeySize = secondKeySize;
        this.encryptedDataSize = encryptedDataSize;
        this.signatureSize = signatureSize;

    }

}
