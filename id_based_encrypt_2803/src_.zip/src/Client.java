
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alex_neigum
 */
public class Client {

byte [] encrypt (String inname, String outname, BigInteger PkID, BigInteger MPK, BigInteger sk, long pk) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException {
        BigInteger t;
        int m = 0;
        int  j;
        long s,s1;
        int bit;
        String binary = null;
        StringBuffer sb = new StringBuffer();
        CipherInputStream cis;
        BigInteger inv_t;
        FileOutputStream fout = new FileOutputStream (outname);
        FileInputStream fin = new FileInputStream (inname);
        DataOutputStream dos = new DataOutputStream (fout);
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128);
       SecretKey skey = kgen.generateKey();
       byte[] raw = skey.getEncoded();
       Sign signature = new Sign ();
   

       SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
       cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
       
       for (int i = 0; i < raw.length; i++) {

       binary = Integer.toBinaryString(raw[i]&0xff);
       if (binary.length() < 8)
           for (int k = 0; k < 8-binary.length(); k++)
                sb.append("0");
       sb.append(binary);
       
       }
     
       BigInteger[] ciphertext = new BigInteger[sb.length()];
       BigInteger[] inv_ciphertext = new BigInteger [sb.length()];
       for (int i = 0; i < sb.length(); i++) {
           m = Character.digit(sb.charAt(i), 10);
           Random rand = new Random ();

        while (true) {
       // t = (int) (rand.nextInt() % MPK);
         t = new BigInteger (MPK.bitLength(),rand);
         t = t.mod(MPK);

        j = ResidueCalculation.Jacobi(t, MPK);
        //+1 = 1; -1 = 0
        if ( m == 0 && j == -1) {
           //inv_t =  ResidueCalculation.inv(t, MPK);
            inv_t = t.modInverse(MPK);
            ciphertext[i] = t.add(PkID.multiply(inv_t)).mod(MPK);
            inv_ciphertext[i] = t.subtract(PkID.multiply(inv_t)).mod(MPK);

//           if (inv_ciphertext[i] < 0) inv_ciphertext[i] = MPK + inv_ciphertext[i];


            break;
        }
 else
     if ( m == 1 && j == 1) {
         inv_t = t.modInverse(MPK);
         ciphertext[i] = t.add(PkID.multiply(inv_t)).mod(MPK);
         inv_ciphertext[i] = t.subtract(PkID.multiply(inv_t)).mod(MPK);
//         if (inv_ciphertext[i] < 0) inv_ciphertext[i] = MPK + inv_ciphertext[i];

         break;

     }
        }



       }
       int key_size1 = 0;
       int key_size2 = 0;
       for (int i = 0; i < ciphertext.length; i++) key_size1 = key_size1+ciphertext[i].toByteArray().length;
       for (int i = 0; i < inv_ciphertext.length; i++) key_size2 = key_size2+inv_ciphertext[i].toByteArray().length;
       dos.writeInt(key_size1+128*4); //записываем длину 1го ключа
       
       dos.writeInt(key_size2+128*4); //записываем длину 2го ключа
       
       //записываем ключевую информацию
       for (int i = 0; i < ciphertext.length; i++) {
           dos.writeInt(ciphertext[i].toByteArray().length);
          
           dos.write(ciphertext[i].toByteArray());
    }
     
       for (int i = 0; i < inv_ciphertext.length; i++) {
           dos.writeInt(inv_ciphertext[i].toByteArray().length);
           
           dos.write(inv_ciphertext[i].toByteArray());
    }
       int data_size = fin.available(); // размер шифруемых данных
       
       byte [] data_to_encrypt = new byte [data_size];
       fin.read(data_to_encrypt);
       //byte[] buffer= cipher.update(data_to_encrypt);
       byte[] encrypted_data = cipher.doFinal(data_to_encrypt);
       int encrypted_data_size = encrypted_data.length;
       
       dos.writeInt(encrypted_data_size);
       //fout.write (encrypted_data);
       dos.write(encrypted_data);



       

//      cis = new CipherInputStream(fin, cipher);
//      byte[] b = new byte[8];
//
//      int i = cis.read(b);
//      while (i != -1) {
//        fout.write(b, 0, i);
//        i = cis.read(b);
//    }
      
      FileInputStream fis = new FileInputStream (outname);
    //  MessageDigest MD = MessageDigest.getInstance("SHA");
      byte [] data_to_hash = new byte[fis.available()];
      fis.read(data_to_hash);
      //MD.update(data_to_hash);
      //byte[] hash = MD.digest();
      BigInteger [] sign = new BigInteger[2];
      sign = signature.getSign(data_to_hash, sk, pk, MPK);
 
    
    //  dos.writeLong(sign[0].longValue());
      dos.writeInt (sign[0].toByteArray().length);
     
      dos.writeInt (sign[1].toByteArray().length);
      
      dos.write(sign[0].toByteArray());
      dos.write(sign[1].toByteArray());
     dos.close();
     fout.close();
     fis.close();
     
     return data_to_encrypt;

      


     




        

    }
byte[] decrypt (String inname, String outname, String id, BigInteger SkID, BigInteger MPK, long pkey) throws FileNotFoundException, IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, DecryptException {
        boolean negative = false;
        BigInteger [] encrypted_aes_key = new BigInteger [128];
        int size_of_encr_keybyte = 0;
        BigInteger pk = Util.genPkID(id, MPK);
        BigInteger quadr = SkID.modPow(BigInteger.valueOf(2), MPK);
        Sign signature = new Sign ();
        if ( quadr.compareTo(pk) == 0) {
          negative = false;
         
        }
        else {
            negative = true;
           
    }
        FileInputStream fin = new FileInputStream(inname);
        DataInputStream ds = new DataInputStream(fin);
        int data_size = fin.available();
        int key_size1 = ds.readInt();
        int key_size2 = ds.readInt();
        ds.skipBytes(key_size1+key_size2);
        int encrypted_data_size = ds.readInt();
        int sign_length = data_size - key_size1 - key_size2 - encrypted_data_size - 12;
        
        ds.close();
        fin.close();
        fin = new FileInputStream(inname);
        ds = new DataInputStream (fin);
        byte [] data = new byte[data_size - sign_length];
        ds.read(data);

        if (sign_length <= 0) return null;
        int size_of_t = ds.readInt();
        int size_of_s = ds.readInt();
        byte [] t_byte = new byte [size_of_t];
        byte [] s_byte = new byte [size_of_s];
        ds.read(t_byte);
        ds.read(s_byte);
        String s;
        String key;
        BigInteger [] sign = new BigInteger [2];
        BigInteger t = new BigInteger(t_byte);
        BigInteger S = new BigInteger(s_byte);
       // long S = ds.readLong();
        sign[0] = t;
        sign[1] = S;
        boolean verify_sign = signature.verifySign(data, id , sign, pkey, MPK);
        
        if (verify_sign == false) return null;

        fin.close();
        ds.close();
        fin = new FileInputStream (inname);
        DataInputStream din = new DataInputStream (fin);
        din.skipBytes(8);

        if ( negative == false) {
            for (int i = 0; i < 128; i++) {
                size_of_encr_keybyte = din.readInt();

                byte [] buff = new byte [size_of_encr_keybyte];
                din.read(buff);
                encrypted_aes_key[i] = new BigInteger (buff);
               

            }
            din.skipBytes(key_size2);
        }

 else
        {
            din.skipBytes(key_size1);
            for (int i = 0; i < 128; i++) {
              size_of_encr_keybyte = din.readInt();
              byte [] buff = new byte [size_of_encr_keybyte];
              din.read(buff);
              encrypted_aes_key[i] = new BigInteger (buff);
              
            }
    }

        int [] binary_aes_key = new int [128];
        for (int i = 0; i < 128; i++) {
    //    int Jacobi = ResidueCalculation.Jacobi((encrypted_aes_key[i] + 2 * SkID)%MPK, MPK);
          int Jacobi = ResidueCalculation.Jacobi ((encrypted_aes_key[i].add(SkID.multiply(BigInteger.valueOf(2)))).mod(MPK), MPK);

       if (Jacobi == 1)
           binary_aes_key[i] = 1;
        else
            if (Jacobi == -1)
                binary_aes_key[i] = 0;
            else {
                 binary_aes_key[i] = 0; // error
                 throw new DecryptException(encrypted_aes_key[i].add(SkID.multiply(BigInteger.valueOf(2))).mod(MPK), SkID, MPK);
    }
    }
        StringBuffer sb = new StringBuffer ();
        for (int i = 0; i < binary_aes_key.length; i++) {
      //      System.out.print (""+binary_aes_key[i]);
            sb.append(binary_aes_key[i]);
        }
      
       int from = 0, to = 8;
       String byte_of_key = new String ();
       byte [] raw = new byte [16];
       String aes_key =  sb.toString();
       for (int i = 0; i < 16; i++) {
       byte_of_key = aes_key.substring(from,to);

     //  raw[i] = Byte.parseByte(byte_of_key, 2);
       raw[i] =  Integer.valueOf(byte_of_key, 2).byteValue();
       from = to;
       to = to + 8;
       }
    //   int encrypted_data_size = din.readInt();
       din.close ();
       SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
       cipher.init(Cipher.DECRYPT_MODE, skeySpec);
       byte [] encrypted_data = new byte [encrypted_data_size];
       System.arraycopy(data, key_size1+key_size2+12, encrypted_data, 0, encrypted_data_size);
       byte [] decrypted_data = cipher.doFinal(encrypted_data);
       FileOutputStream fos = new FileOutputStream (outname);
       fos.write(decrypted_data);
       fos.close();
       return decrypted_data;

    }
public static void main_ (String[] args) throws FileNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException, DecryptException {
    PKG pkg = new PKG (512);
    String id = "foxneig@gmail.com";
    pkg.setup();
    pkg.keyExtract(id);
    pkg.getSecretExponent();
    BigInteger PkID = Util.genPkID(id, pkg.MPK);
    
  


    Client client = new Client();
//    args[0] = "in.pdf";
//    args[1] = "out";
//    if (args.length < 2) {
//        System.out.println ("Usage id_based_encrypt.jar -in -out");
//        System.exit(0);
//    }
    BigInteger skey = pkg.signKeyExtract("foxneig@gmail.com");
    byte [] data_to_encrypt  = client.encrypt("1.pdf", "out.dat", PkID, pkg.MPK, skey, pkg.e);
    byte [] decr_data = client.decrypt("out.dat", "decr","foxneig@gmail.com", pkg.MSK, pkg.MPK, pkg.e);
    System.out.println ("Decrypt: "+Arrays.equals(data_to_encrypt, decr_data));



//   BigInteger [] sign = client.getSign(decr_key, skey, pkg.e, pkg.MPK);
//  // decr_key[0] = 15;
//  System.out.println ("Status: "+ client.verifySign(decr_key, id, sign, pkg.e, pkg.MPK));
  

}
}
