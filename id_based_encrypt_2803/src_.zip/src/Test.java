
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alex_neigum
 */
public class Test {


    
   
    void TestFileEncrypt (long num, String id, boolean rand_enable) throws UnsupportedEncodingException, FileNotFoundException, IOException, NoSuchAlgorithmException{
        PKG pkg = new PKG (512);
        ClientNew client = new ClientNew();
        BigInteger PkID;
        BigInteger skey;
        byte [] data_to_encrypt = null;
        byte [] decr_data = null;
        int err_num = 0;
        Random rand = new Random();
        PrintWriter writer = new PrintWriter(
             new OutputStreamWriter(
             new FileOutputStream("TestEncryptError.txt"), "windows-1251"));
        for (int i = 0; i < num; i++) {
            if (i%10 == 0 ) System.out.println ("Experiment "+i);

        pkg.setup();
        pkg.keyExtract(id);
        pkg.getSecretExponent();
        PkID = Util.genPkID(id, pkg.MPK);
        skey = pkg.signKeyExtract(id);
        if (rand_enable == true) {
        int size = Math.abs(rand.nextInt(1000000));
        data_to_encrypt = new byte[size];
        rand.nextBytes(data_to_encrypt);
        FileOutputStream fout = new FileOutputStream ("in.txt");
        fout.write(data_to_encrypt);
        fout.close();
            }
            try {
                data_to_encrypt = client.encrypt("in.txt", "out.dat", PkID, pkg.MPK, skey, pkg.e);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchPaddingException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeyException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalBlockSizeException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadPaddingException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                try {
                    decr_data = client.decrypt("out.dat", "decr", id, pkg.MSK, pkg.MPK, pkg.e);
                } catch (DecryptException ex) {
                   ex.writeParam(writer);
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchPaddingException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeyException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalBlockSizeException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadPaddingException ex) {
              //  err_num++;
                decr_data = null;
                writer.write ("javax.crypto.BadPaddingException: Given final block not properly padded \n");
                continue;
                //Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }
        if (Arrays.equals(data_to_encrypt, decr_data) == false) {
            err_num++;
            writer.write("MasterPublicKey = "+pkg.P + "*"+pkg.Q +" = "+pkg.MPK + "\n");
            writer.write ("Public Key: "+PkID + "\n");
            writer.write ("Secret exponent: "+pkg.d +"\n");
            writer.write ("Secret signed key:" +pkg.SSK +"\n");

        }


        }
        writer.write ("Err_number: "+err_num +"\n");
        writer.close();
    }
    void NegativeDecryptTest (long num, String id) throws UnsupportedEncodingException, FileNotFoundException, IOException, NoSuchAlgorithmException{
        PKG pkg = new PKG (512);
        ClientNew client = new ClientNew();
        BigInteger PkID;
        BigInteger skey;
        byte [] data_to_encrypt = null;
        byte [] decr_data = null;
        int err_num = 0;
        Random rand = new Random();




        PrintWriter writer = new PrintWriter(
             new OutputStreamWriter(
             new FileOutputStream("NegativeTestSignError.txt"), "windows-1251"));
        for (int i = 0; i < num; i++) {
            if (i%10 == 0 ) System.out.println ("Experiment "+i);
        pkg.setup();
        pkg.keyExtract(id);
        pkg.getSecretExponent();
        PkID = Util.genPkID(id, pkg.MPK);
        skey = pkg.signKeyExtract(id);
        int size = Math.abs(rand.nextInt(1000000));
        data_to_encrypt = new byte[size];
        rand.nextBytes(data_to_encrypt);
        FileOutputStream fout = new FileOutputStream ("out.dat");
        fout.write(data_to_encrypt);
        fout.close();
            try {
                try {
                    decr_data = client.decrypt("out.dat", "decr", id, pkg.MSK, pkg.MPK, pkg.e);
                } catch (DecryptException ex) {
                    ex.writeParam(writer);
                }
                data_to_encrypt = null;
            } catch (IOException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchPaddingException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeyException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalBlockSizeException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadPaddingException ex) {
                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (decr_data != null) {
            System.out.println ("Error");
            writer.write("MasterPublicKey = "+pkg.P + "*"+pkg.Q +" = "+pkg.MPK + "\n");
            writer.write ("Public Key: "+PkID + "\n");
            writer.write ("Secret exponent: "+pkg.d +"\n");
            writer.write ("Secret signed key:" +pkg.SSK +"\n");

            }
    }
    }

    void SignTest (long num, String id, boolean negative) throws UnsupportedEncodingException, FileNotFoundException, NoSuchAlgorithmException {
        PKG pkg = new PKG (512);
        ClientNew client = new ClientNew();
        Sign signature = new Sign ();
        BigInteger PkID;
        BigInteger skey;
        byte [] data;
        int err_num = 0;
        Random rand = new Random();
        PrintWriter writer = new PrintWriter(
             new OutputStreamWriter(
             new FileOutputStream("TestSignOnlyError"+!negative+".txt"), "windows-1251"));
        for (int i = 0; i < num; i++) {
            if (i%1000 == 0 ) System.out.println ("Experiment "+i);
        pkg.setup();
        pkg.keyExtract(id);
        pkg.getSecretExponent();
        PkID = Util.genPkID(id, pkg.MPK);
        skey = pkg.signKeyExtract(id);
        int size = Math.abs(rand.nextInt(1000000));
        data = new byte[size];
        rand.nextBytes(data);
        BigInteger [] sign = signature.getSign(data, skey, pkg.e, pkg.MPK);

        if (negative == true) {
            int round = rand.nextInt(20);
            for (int j = 0; j < round; j++) {
            int pos = rand.nextInt(data.length-1);
            data[pos] = (byte) (data[pos] + (byte) rand.nextInt());
            }
            boolean verify = signature.verifySign(data, id, sign, pkg.e, pkg.MPK);

        if (verify != false) {
            writer.write("MasterPublicKey = "+pkg.P + "*"+pkg.Q +" = "+pkg.MPK + "\n");
            writer.write ("Public Key: "+PkID + "\n");
            writer.write ("Secret exponent: "+pkg.d +"\n");
            writer.write ("Secret signed key:" +pkg.SSK +"\n");

        }
            }
 else {
            boolean verify = signature.verifySign(data, id, sign, pkg.e, pkg.MPK);
            if (verify != true) {

            writer.write("MasterPublicKey = "+pkg.P + "*"+pkg.Q +" = "+pkg.MPK + "\n");
            writer.write ("Public Key: "+PkID + "\n");
            writer.write ("Secret exponent: "+pkg.d +"\n");
            writer.write ("Secret signed key:" +pkg.SSK +"\n");

            }
 }





        }

    }




public static void main (String[] args) throws UnsupportedEncodingException, FileNotFoundException, IOException, NoSuchAlgorithmException {
    
   
    long quadr;
    Test test = new Test();


   //   test.testExtract(1000);
   // System.out.println ("TestExtract \n");
   //test.testExtract(1000000000, "foxneig12345@exampleserver.com");
  //System.out.println ("TestEncrypt \n");
    //test.testEncrypt(1000000000, "foxneig12345@exampleserver.com");
    long start = System.currentTimeMillis();
    System.out.println ("Testing file encrypt/decrypt...");
    test.TestFileEncrypt(1000, "foxneig@gmail.com", true);
    System.out.println ("Negative testing random file decrypt...");
    test.NegativeDecryptTest(1000, "foxneig@gmail.eu");
    System.out.println ("Testing only signing... (negative)");
    test.SignTest(1000, "foxneig@mail.ru",true);
    System.out.println ("Testing only signing... (positive)");
    test.SignTest(1000, "blabla@gmail.com", false);
    long end = System.currentTimeMillis();
    System.out.println ("Done. RunningTime: "+(end-start)/1000);

   // test.NegativeDecryptTest(100000, "foxneig@gmail.com");

    
  
    }
}
